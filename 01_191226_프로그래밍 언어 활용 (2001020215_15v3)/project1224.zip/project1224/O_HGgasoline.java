package project1224;

public class O_HGgasoline extends OilData {

	public static void main(String[] args) {
		String dMenu = "0";
		int price = 1659;
		int pr;
		int liter = 1;
		int lt;
		od : do {
			System.out.println("┏━　고급휘발유　　　선택　━┓");
			System.out.println("┣━━━━━━━━━━━━━━┫");
			System.out.println("┣━　　　　SELECT !　　　　━┫");
			System.out.println("┃1]\t금액으로 주유\t      ┃");
			System.out.println("┃2]\tℓ 단위로 주유\t      ┃");
			System.out.println("┣━━━━━━━━━━━━━━┫");
			System.out.print("　▶ 메뉴 선택 : ");
			dMenu = sc.nextLine();
			switch (dMenu) {
			case "1":
				System.out.println(" ▼ 금액을 입력하세요 ▼ ");
				pr = sc.nextInt();
				System.out.printf("━\t%s원 입력\t━\n", pr);
				System.out.println("━\t주유를 시작합니다\t━");
				System.out.println("━━━━━━━━━━━━━━━━━");
				System.out.println("━━━━━━━━━━━━━━━━━");
				System.out.println("━━━━━━━━━━━━━━━━━");
				System.out.println("━\t주유를 완료합니다\t━");
				System.out.printf("━\t결제 금액 : %s원\t━\n",	pr);
				System.out.printf("━\t주유량 : %sℓ\t━\n", (pr/price));
				break;
			case "2":
				System.out.println(" ▼ ℓ를(을) 입력하세요 ▼ ");
				lt = sc.nextInt();
				System.out.printf("━\t%sℓ 입력\t\t━\n", lt);
				System.out.println("━\t주유를 시작합니다\t━");
				System.out.println("━━━━━━━━━━━━━━━━━");
				System.out.println("━━━━━━━━━━━━━━━━━");
				System.out.println("━━━━━━━━━━━━━━━━━");
				System.out.println("━\t주유를 완료합니다 \t━");
				System.out.printf("━ \t결제 금액 : %s원\t━\n",	(lt*price));
				break;
			default:
				System.out.println("━━━━━━━━━━━━━━━━━");
				break od;
			}
			break;
		} while (true);
		
		System.out.println("━━━━━━━━━━━━━━━━━");
		System.out.println("━\t주유 완료\t\t━");
		System.out.println("━\t대단히 감사합니다\t━");
	}


}
