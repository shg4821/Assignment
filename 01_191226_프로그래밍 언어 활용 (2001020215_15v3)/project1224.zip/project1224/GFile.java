package project1224;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Objects;

public class GFile {
	// 타입을 유지하면 파일에 저장
	public static void writeObject(String fname, Object obj) {
		// 예외처리
		/*
		 try {
		 	실행시 예외상황이 의심되는 코드		
		} catch (Exception e) {  // try 블럭에 예외상황이 발생하면 실행되는 메서드
			예외발생시 실행될 명령들
		} 
		 * */
		// 변수
		String fn = "C:\\java\\javaws\\pFirst\\src\\project1224\\dir\\" + fname;
				
		try {
			// 스트림화 : 데이터직렬화 바이트단위로 나열
			FileOutputStream fos = new FileOutputStream(fn);
			// 스트림버퍼 : 스트림을 담는 역할
			BufferedOutputStream bos = new BufferedOutputStream(fos);
			// 오브젝트화 : 
			ObjectOutputStream out = new ObjectOutputStream(bos);
			// 객체를 유지하면 저장
			out.writeObject(obj);
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.printf("예외 : %s", e.getMessage());
		}
		
	}
	
	// 파일의 저장된 내용 저장시 타입으로 복원 
	public static Object readObject(String fname) {
		// 변수
		Object obj = null;
		String fn = "C:\\java\\javaws\\pFirst\\src\\project1224\\dir\\" + fname;
		
		try {
			// 스트림화
			FileInputStream fis = new FileInputStream(fn);
			// 스트림 버퍼 사용
			BufferedInputStream bis = new BufferedInputStream(fis);
			// 객체읽기
			ObjectInputStream in = new ObjectInputStream(bis);
			obj = in.readObject();
			in.close();
		} catch (Exception e) {
			System.out.printf("readObject 예외 : %s \n", e.getMessage());
		}
		// 객체를 리턴
		return Objects.isNull(obj) ? null : obj;
	}
}
