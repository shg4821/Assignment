package project1224;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

import mem_manager.GFile;
import mem_manager.Member;

public class ClientM implements Serializable {
	static ArrayList<ClientM> cms;
	// 정적블럭
	static {
		// 파일 로딩
		cms = (ArrayList<ClientM>)
				project1224.GFile.readObject("cmem.txt");
		System.out.println();
		// 파일이 없으면  생성
		if (Objects.isNull(cms)) {
			cms = new ArrayList<ClientM>();
		}
	}
	
	// 동적변수
	String name;
	String cpnum;
	String cmnum; 
	
	// 멤버목록
	static void listMember() {
		
		System.out.println("┏━━━━━━━━━━━━━┓");
		System.out.println("┣━━━━ 회원목록 ━━━━┫");
		System.out.println("┣━━━━━━━━━━━━━┫");
		for (ClientM cm : cms) {
			System.out.printf("┃ %s\t%s ┃ \n", cm.name, cm.cpnum);
			System.out.println("┣━━━━━━━━━━━━━┫");
		}
		System.out.println("┣━━━━━━━━━━━━━┫");
		System.out.println("┣━━━━ 목록종료 ━━━━┫");
		System.out.println("┗━━━━━━━━━━━━━┛");
		System.out.println();
	};
	
	// 종료처리
	static void saveFile() {
		System.out.println(cms);
		project1224.GFile.writeObject("cmem.txt", cms);
	}
}
