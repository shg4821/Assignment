package project1224;

import mem_manager.Member;

public class Pj_OilMain {
	
	public static void main(String[] args) {
		System.out.println("　 * ~ \t환영합니다 !\n * ~　영등포 주유소입니다 !");
		System.out.println("");
		System.out.println("■ 메뉴를 선택해주세요 ! ■");
		System.out.println("");
		// 변수 
		String oMenu = "0";
		String selMenu = "0";
		ClMem cm = new ClMem();
		MgrMem mm = new MgrMem();
		// 시작
		dm : do {
			// 메뉴
			System.out.println("■■■　=　ME　NU　=　■■■");
			System.out.println("■ 1 ┃ 주유\t\t　■");
			System.out.println("■ 2 ┃ 회원등록\t　■");
			System.out.println("■ 3 ┃ 회원 조회\t　■");
			System.out.println("■ 4 ┃ 관리자\t\t　■");
			System.out.println("■ 0 ┃ 종료\t\t　■");
			System.out.println("■■■　　　　　　　　■■■");
			System.out.print("　▶ 선택 : ");
			oMenu = mm.s.nextLine();
			switch (oMenu) {
			case "1":
				System.out.println("■■■　=　ME　NU　=　■■■");
				System.out.println("■ 1 ┃ 경유\t\t　■");
				System.out.println("■ 2 ┃ 휘발유\t\t　■");
				System.out.println("■ 3 ┃ 고급휘발유\t　■");
				System.out.println("■ 0 ┃ 뒤로\t\t　■");
				System.out.print("　▶ 선택 : ");
				selMenu = mm.s.nextLine();
				switch (selMenu) {
				case "1":O_diesel.main(args);
					break;
				case "2":O_gasoline.main(args);
					break;
				case "3":O_HGgasoline.main(args);
					break;
				default:
					break;
				}
				break;
			case "2":
				cm.joinMem();
				break;
			case "3":
				cm.askMem();
				break;
			case "4":
				mm.main();
				break;
			default:
				ClientM.saveFile();
				break dm;
			}
		} while (true);
		System.out.println("이용해주셔서 감사합니다.");
	}
}
