package project1224;

import java.util.Scanner;

public class OilData {
	
	static Scanner sc = new Scanner(System.in);
	int price;
	int liter;

}
