package project1224;

import java.util.Objects;

import mem_manager.Employee;
import mem_manager.Member;

public class MgrMem implements IClientMember{
	
	public void main() {
		mgm : do {
			String mgrmn = "0";
			System.out.println("━  　　관리자 모드로 시작합니다　　   ━");
			System.out.println();
			System.out.println("━\t[1] 멤버 등록\t━");
			System.out.println("━\t[2] 멤버 조회\t━");
			System.out.println("━\t[3] 멤버 목록\t━");
			System.out.println("━\t[0] 종료\t━");
			System.out.print(" ▶ 선택 : ");
			mgrmn = s.nextLine();
			switch (mgrmn) {
			case "1":
				joinMem();
				break;
			case "2":
				askMem();
				break;
			case "3":
				ClientM.listMember();
				break;
			default:
				break mgm;
			}
		} while (true);
	}

	@Override
	public void joinMem() {
		System.out.println("━━━━━━━━━━━━━━━━━━");
		System.out.println("━\t멤버 등록 (관리자)\t━");
		System.out.println("━━━━━━━━━━━━━━━━━━");
		// 직원변수
		DMem dm = new DMem();
		dm.memnum = (dm.cpnum.substring(7));
		System.out.print("▶ 이름 : "); 
		dm.name = s.nextLine();
		System.out.print("▶ 휴대폰번호(- 없이 입력) : "); 
		dm.cpnum = s.nextLine(); 
		System.out.printf("▶  회원번호 : %s \n", dm.memnum); 
		// 공통변수에 등록
		ClientM.cms.add(dm);
		System.out.println("──────────────────");
		System.out.println("── 등록 완료 (관리자) ──");
		System.out.println("──────────────────");
		System.out.println();
		
	}

	@Override
	public void askMem() {
		System.out.println("──────────────────");
		// 조회할 사원선택
		System.out.print("▶ 회원 번호 : ");
	 	String memnum = s.nextLine();
		DMem dm = null;
		for (ClientM cm : ClientM.cms) {
			dm = (DMem)cm;
			if(dm.memnum.equals(memnum)) {
				break;
			}
		}
		if (Objects.isNull(dm)) {
			System.out.println("─! 등록 되지 않은 회원 !─");
		} else {
			System.out.printf("─\t%s\t님\t─\n", dm.name);
			System.out.println("──────────────────");
			System.out.printf("─\t휴대폰번호 : %s \t─\n회원번호 : %s\t─\n", dm.cpnum, dm.memnum);
			System.out.println("──────────────────");
			
		}
		
		System.out.println("──────────────────");
		System.out.println("──── 회원정보 종료 ────");
		System.out.println("──────────────────");
		System.out.println();
	}
	

}
