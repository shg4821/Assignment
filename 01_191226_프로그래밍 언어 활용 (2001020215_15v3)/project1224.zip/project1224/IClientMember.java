package project1224;

import java.util.Scanner;

public interface IClientMember {
	// 정적변수 스캐너 
	static Scanner s = new Scanner(System.in);
	//멤버 등록
	void joinMem();
	// 멤버 조회
	void askMem();

}
