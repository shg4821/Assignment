package project1224;

public class DMem extends ClientM {
	// 변수
	String memnum; // 회원번호
	String grade; // 회원등급 

}
